#include <stdio.h>

void imprime_cabecalho(FILE *f, cenarios *v, int i);

void imprime_dados(FILE *f, cenarios *v, int i);

void libera_c(cenarios **c);
