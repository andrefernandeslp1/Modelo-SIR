#include <stdio.h>

void calcula_b_k(cenarios *v, int i);

void calcula_sir(cenarios *v, int i);
